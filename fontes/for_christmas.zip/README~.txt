
[By installing or using this font, you are agree to the Product Usage Agreement]

=============================== [ 0 ] =========================================

	    This font is for PERSONAL USE ONLY (Non-Profit Activity).
	          [ NOT ALLOWED for Commercial Use ] in any form.

===============================================================================
 

if you are interested to buy it, you can contact me for more info: jadaakbaaal@gmail.com


============================ Thank you ========================================
